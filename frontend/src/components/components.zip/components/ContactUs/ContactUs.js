import React from 'react';
import './ContactUs.css'; // Ensure the file exists and is correctly linked
import backgroundImage from '../../assets/ContactUs.jpg'; // Ensure the image path is correct

const ContactUs = () => {
  console.log('Contact Us Page Loaded'); // For debugging

  return (
    <div 
      className="contact-us"
      style={{
        width: '100%',
        backgroundImage: `url(${backgroundImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        minHeight: '100vh',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'right',
        position: 'relative',
      }}
    >
      {/* Gradient Overlay for readability */}
      <div className="overlay"></div>

      <div className="contact-content">
        <h1>Contact Us</h1>
        <p>
          We're here to help! Feel free to reach out with any inquiries or feedback.
        </p>
        <form className="contact-form">
          <input type="text" name="name" placeholder="Your Name" required />
          <input type="email" name="email" placeholder="Your Email" required />
          <textarea name="message" placeholder="Your Message" rows="4" required></textarea>
          <button type="submit">Send Message</button>
        </form>
      </div>
    </div>
  );
};

export default ContactUs;
