import React from 'react';

const Checkout = () => {
  return (
    <div className="checkout-page">
      <h1>Checkout Page</h1>
      <p>Thank you for your purchase! Proceed with your payment.</p>
      {/* Add your checkout form or payment options here */}
    </div>
  );
};

export default Checkout;
